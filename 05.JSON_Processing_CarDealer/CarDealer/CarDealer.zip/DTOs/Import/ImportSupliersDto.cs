﻿namespace CarDealer.DTOs.Import;

public class ImportSupliersDto
{
    public string Name { get; set; } = null!;

    public bool IsImporter { get; set; }
}
