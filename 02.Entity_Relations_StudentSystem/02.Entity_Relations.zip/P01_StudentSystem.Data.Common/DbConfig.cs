﻿namespace P01_StudentSystem.Data.Common;

public static class DbConfig
{
    public const string ConnectionString =
        @"Server=.;Database=StudentSystem;Trusted_Connection=True;Trust Server Certificate=true";
}