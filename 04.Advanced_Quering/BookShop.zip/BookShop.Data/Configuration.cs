﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => @"Server=DESKTOP-23ATDCK;Database=BookShop;Integrated Security=True;";
    }
}
